var postgresql = require('pg');
var databaseConfig = "postgres://postgres:postgres@127.0.0.1:5432/varma";

var client = new postgresql.Client(databaseConfig);
client.connect();

function getBlogs(res) {
   
    console.log('in getBlogs Function');
    const results = [];

    var query = client.query("SELECT * FROM blogs");

	//can stream row results back 1 at a time
    query.on('row', function(row) {
    console.log(row);
    results.push({
      blog_id: row.blog_id,
      created_on: row.created_on,
      comments: row.comments,
      likes: row.likes,
      blogdata:row.blog_data,
      blogtitle:row.blog_title,
      author:row.author
    })
	});

    query.on('end', function() {
    console.log(results);
    res.json(results); // return all tasks in JSON format
    //client.end();
	});

    query.on('error',function() {
    console.log('Error in Query');
    res.json(results);
    });
    
   
};

module.exports = function (app) {

    app.post('/api/blogs', function (req, res) {
        console.log('In Create blogs');
        console.log(req.body);
        /*String.prototype.replaceAll = function(search,replacement) {
            var target = this;
            return target.split(search).join(replacement);
        }*/
        
        var query = client.query("INSERT INTO blogs(created_on,comments,likes,blog_data,blog_title,author) VALUES($1,$2,$3,$4,$5,$6)",[req.body.created_on,req.body.comments,req.body.likes,req.body.blogbody,req.body.title,req.body.author]);
        query.on('end',function() {
            getBlogs(res);
        });

        query.on('error',function() {
            console.log('Error in Query');
            getBlogs(res);
        });
    });

    

    app.post('/api/todos/:task_id:task',function(req,res) {
        console.log('In update TODO');
        console.log(req.body.task_id);
        var query = client.query("UPDATE taskstodo SET task = " + "'" + req.body.task + "'" + " WHERE task_id = " + "'" + req.body.task_id + "' ;");
        query.on('end',function() {
            getTodos(res);
        });

        query.on('error',function() {
            console.log('Error in Query');
            getTodos(res);
        });
    });

    app.delete('/api/todos/:todo_id', function (req, res) {
        console.log(req.params.todo_id);
        var query = client.query('DELETE FROM taskstodo WHERE task_id = ' + req.params.todo_id + ' ;');
        query.on('end',function() {
            getTodos(res);
        });

        query.on('error',function() {
            console.log('Error in Query');
        });
    });
	
    app.get('/api/blogs', function (req, res) {
        // use postgresql to get all tasks from the database
        getBlogs(res);
    });

    // application -------------------------------------------------------------
    app.get('*/home', function (req, res) {
	console.log('hi this is redirected to index.html');
        res.sendFile(__dirname + '/public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
    });
};
