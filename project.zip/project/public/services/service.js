angular.module('blogService', [])
 
	.factory('Blog', ['$http',function($http) {
		return {
			get : function() {
				console.log('In Service function');
				return $http.get('/api/blogs');
			},
			create : function(blogdata) {
				console.log('In Create function');
				console.log(blogdata);
				return $http.post('/api/blogs', blogdata);
			},
			delete : function(id) {
				return $http.delete('/api/todos/' + id);
			},

			update : function(data) {
				return $http.post('/api/todos/update',data);
			}
		}
	}]);
