angular.module('blogapp', ['blogController','comment','blogService']);
