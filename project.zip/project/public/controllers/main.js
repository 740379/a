angular.module('blogController', ['ui.tinymce','ngSanitize'])

	// inject the Todo service factory into our controller
	.controller('mainController', ['$scope','$http','Blog', function($scope, $http, Blog) {
		var blog = this;

		$scope.tinymceOptions = {
    	plugins: 'link image code',
    	toolbar: 'undo redo | bold italic | alignleft aligncenter alignright | code',
    	width:600,
    	height:200
  		};

		// Fetch blogs from database and save in this Variable..
		blog.posts = {};

		console.log('In mainController');

		Blog.get()
			.success(function(data) {
				console.log('data received is ',data);
				blog.posts = data;
		});

		blog.tab = 'blog';

		blog.selectTab = function(setTab) {
      	blog.tab = setTab;
      	console.log(blog.tab)
    	};

    	blog.isSelected = function(checkTab) {
      	return blog.tab === checkTab;
    	};	

		blog.post = {};
    	blog.addPost = function() {

    	console.log('In add Function');	
    	console.log(blog.post.body);
    	var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!
		var yyyy = today.getFullYear();

		if(dd<10) {
    		dd='0'+dd
		} 

		if(mm<10) {
   		 mm='0'+mm
		} 

		today = mm+'/'+dd+'/'+yyyy;

		console.log(blog.post.body[0]);
    	
    	var blogcreated = {
      		title: blog.post.title,
      		created_on: today,
      		blogbody : blog.post.body,
      		author: blog.post.author,
      		likes:0,
      		comments:{}
      	}
      	console.log(blogcreated);
       	Blog.create(blogcreated)
					// if successful creation, call our get function to get all the new Blogs
					.success(function(data) {
						blog.posts = data;
						blog.tab = 'blog';
      					blog.post = {};
					});
   		};



}]);



