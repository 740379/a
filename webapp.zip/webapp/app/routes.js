var postgresql = require('pg'),
    databaseConfig = "postgres://postgres:123456@localhost/testdb";

var client = new postgresql.Client(databaseConfig);
client.connect();

function getData(res) {

    var query = client.query("SELECT * FROM data1");

    var results = [];

    query.on('row', function (row) {
        results.push({
            value: row.value
        })
    });

    query.on('end', function () {
        var resultsArray = [];
        for (var i = 0; i < results.length; i++) resultsArray.push(results[i].value);
        res.json(resultsArray);
    });

    query.on('error', function () {
        console.log('Error in Query');
        res.json(results);
    });
};

module.exports = function (app) {
    // application -------------------------------------------------------------
    app.get('/myPortfolioPage/data', function (req, res) {
        getData(res);
    });

    app.get('*/home', function (req, res) {
        res.sendFile(__dirname + '/public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
    });
};
