// Setting up required node modules
var express = require('express'),
    app = express(),
    postgresql = require('pg'),
    port = process.env.PORT || 8081,
    databaseConfig = "postgres://postgres:123456@localhost/testdb",
    morgan = require('morgan'),
    bodyParser = require('body-parser'),
    methodOverride = require('method-override');
app.use(express.static('./public'));

// Postgresql DataBase Configuration & Testing
var client = new postgresql.Client(databaseConfig);
client.connect();

// =========== 
app.use(morgan('dev')); // log every request to the console
app.use(bodyParser.urlencoded({
    'extended': 'true'
})); // parse application/x-www-form-urlencoded
app.use(bodyParser.json()); // parse application/json
app.use(bodyParser.json({
    type: 'application/vnd.api+json'
})); // parse application/vnd.api+json as json
app.use(methodOverride('X-HTTP-Method-Override')); // override with the X-HTTP-Method-Override header in the request




// Setting up routes
var routes = require('./app/routes.js')(app);

// listen (start app with node server.js) 
app.listen(port);
console.log("App listening on port " + port);