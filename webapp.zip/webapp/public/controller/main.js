angular.module('webappController', [])

	// inject the Todo service factory into our controller
	.controller('mainController', ['dataObject', function( dataObject) {
		var controllerObject = this;
		// Fetch blogs from database and save in this Variable..
		controllerObject.dataVariable = {};
		dataObject.get()
			.success(function(data) {
				controllerObject.dataVariable = data;
                testName(data);
		});
}]);



