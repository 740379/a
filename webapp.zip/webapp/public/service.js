angular.module('webappService', [])
.factory('dataObject', ['$http', function ($http) {
    return {
        get: function () {
            return $http.get('/myPortfolioPage/data');
        }
       /* , create: function (blogdata) {
            console.log('In Create function');
            console.log(blogdata);
            return $http.post('/api/blogs', blogdata);
        },
        delete: function (id) {
            return $http.delete('/api/blogs/' + id);
        },
        update: function (data) {
            return $http.post('/api/blogsupdate', data);
        }*/
    }
	}]);