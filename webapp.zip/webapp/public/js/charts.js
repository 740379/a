function getRandomColor() {
    var color = "";
    color += Math.floor(Math.random() * 255) + ",";
    color += Math.floor(Math.random() * 255) + ",";
    color += Math.floor(Math.random() * 255);
    return "rgba(" + color + ",.8)";
}

function testName(dataVariable) {
    var ctx = document.getElementById("myDoughnutChart");

    var myDoughnutChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [
                "Manager A",
                "Manager B",
                "Manager C",
                "Manager D",
                "Manager E"

            ],
            datasets: [{
                data: dataVariable,
                backgroundColor: [
                   getRandomColor(),
                   getRandomColor(),
                   getRandomColor(),
                   getRandomColor(),
                   getRandomColor()
                ],
                hoverBackgroundColor: [
                    getRandomColor(),
                   getRandomColor(),
                   getRandomColor(),
                   getRandomColor(),
                   getRandomColor()
                ]
            }]
        }
    });

}
