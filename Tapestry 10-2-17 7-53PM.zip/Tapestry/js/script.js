'use strict';

/*---------------------------------------------------------------------------------
                                    HEADER MENU
---------------------------------------------------------------------------------*/
// show / hide menu
var overlayMenu = $('.header .menu-wrap');

overlayMenu.children('.cross-btn').add('.header .ham-icon').click(function() {
	overlayMenu.toggleClass('menu-active');
});

// Click on anything(glass or body) other than the menu-items-wrap
$('body').on('click', function(event) {
	event.stopPropagation();
	// console.log(event.target);
	
	var target = $(event.target);

	if (!(target.hasClass('ham-icon')) && !(target.hasClass('menu')) && !(target.parent().hasClass('fancy-input'))) {
		overlayMenu.removeClass('menu-active');
		// console.log('Will close');
	}
});

// expansion of fancy input box when icon is clicked
$('.header .fancy-input a').click(function(event) {
	event.preventDefault();
	
	$(this).parent('.fancy-input').addClass('fi-active');
	$(this).siblings('input[type="text"]').focus();
});

// Click on anything other than the text-box
$('body').on('click', function(event) {
	event.stopPropagation();
	// console.log(event.target);
	
	if (!$(event.target).parent().hasClass('fancy-input')) {
		$('.fancy-input').removeClass('fi-active');
	}
});

/*---------------------------------------------------------------------------------
                                    CAROUSEL
---------------------------------------------------------------------------------*/
// Initialize Carousel
var carouselList = $('.carousel'),
	slideDuration = 600, // Same as transition duration
	lastIndicatorClick;

carouselList.each(function() {

	// Adding handlers to carousel indicators
	if ($(this).children('.carousel-indicator-wrap').length > 0) {
		var activeItemIndex = $(this).children('.carousel-item.active').index();

		// Add 'active' class to indicator
		$(this).find('.carousel-indicator').eq(activeItemIndex).addClass('active');
		$(this).find('.carousel-indicator').click(function() {
			if (processCarouselClick()) {
				slideToItem($(this).closest('.carousel').children('.carousel-item').eq($(this).index()));
			}
		});
	}

	// Adding handlers to carousel controls
	$(this).find('.carousel-control').click(function() {
		if (processCarouselClick()) {
			var activeItem = $(this).closest('.carousel').children('.carousel-item.active'),
				nextItem = activeItem.next(),
				prevItem = activeItem.prev(),
				goToItem;

			if ($(this).hasClass('next')) {
				goToItem = nextItem.hasClass('carousel-item') ? nextItem : activeItem.siblings().eq(0);
			}
			else {
				goToItem = prevItem.hasClass('carousel-item') ? prevItem : activeItem.siblings('.carousel-item').last();
			}

			slideToItem(goToItem);
		}
	});
});

// Validates the click event
function processCarouselClick() {
	var currentIndicatorClick = new Date().getTime(),
		clickStatus = false;

	if (lastIndicatorClick == null || currentIndicatorClick-lastIndicatorClick > slideDuration) {
		clickStatus = true;
		lastIndicatorClick = currentIndicatorClick;
	}

	return clickStatus;
}

// Slides to the successive item
function slideToItem(successiveItem) {
	var carousel = successiveItem.closest('.carousel'),
		activeItem = carousel.find('.carousel-item.active'),
		activeItemIndex = activeItem.index(),
		successiveItemIndex = successiveItem.index();

	// Slide left
	if (activeItemIndex < successiveItemIndex) {
		successiveItem.addClass('next');
		// Delay between class changes
		setTimeout(function() {
			activeItem.add(successiveItem).addClass('left');
		}, 30);

		setTimeout(function() {
			activeItem.removeClass('active left');
			successiveItem.removeClass('next left').addClass('active');
		}, slideDuration);
	}
	// Slide right
	else if ( activeItemIndex > successiveItemIndex) {
		successiveItem.addClass('prev');
		// Delay between class changes
		setTimeout(function() {
			activeItem.add(successiveItem).addClass('right');
		}, 30);

		setTimeout(function() {
			activeItem.removeClass('active right');
			successiveItem.removeClass('prev right').addClass('active');
		}, slideDuration);
	}

	// Update carousel indicator
	carousel.find('.carousel-indicator').eq(successiveItemIndex).addClass('active').siblings().removeClass('active');
}


/*---------------------------------------------------------------------------------
                                       TRASH
---------------------------------------------------------------------------------*/
var headerHeight = $('header.header').outerHeight(),
	page = $('html, body'),
	targetOffset;

$('a').click(function() {
	var targetID = $(this).attr('href');

	if (targetID.startsWith('#') & targetID.length > 1) {
		page.animate({ scrollTop : $(targetID).offset().top - headerHeight }, 500); // offset header height
	}
});

// delayed execution is needed in chrome
setTimeout(function() {
	targetOffset = $(':target').offset();

	if(targetOffset) {
		page.animate({ scrollTop : targetOffset.top - headerHeight }, 0); // offset header height
	}
}, 100);



/*---------------------------------------------------------------------------------
                                       TRASH
---------------------------------------------------------------------------------*/
