<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>People</title>

    <meta name="generator" content="Bootply" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
    <link href="css/styles.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC|Loved+by+the+King" rel="stylesheet">

</head>

<body>



    <!--main-->
    <div class="container">
        <div class="row">
            <!--left-->
            <div class="col-md-3" id="leftCol">
                <ul class="nav nav-stacked" id="sidebar">
                    <li><img class="img-circle" src="http://placehold.it/200x200">
                    </li>
                    <li><a href="#sec1">Listen</a>
                    </li>
                    <!-- <li><a href="#guests">Guests</a>
                    </li> -->
                    <li><a href="#madhav">Host</a>
                    </li>
                    <li><a href="#contact">Contact Us</a>
                    </li>
                </ul>
            </div>
            <!--/left-->

            <!--right-->
            <div class="col-md-9">
                <h1 id="sec0">Hi There! </h1>
                <p>
                    Im Madhav
                    <br> Welcome to People! Here I hang out with interesting people</p>

                <hr>


                <h2 id="sec1">Podcasts</h2>

                <div>
                    <h3 id="rolandJenson" >Roland Jenson</h3>
                    <iframe width="100%" height="166" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/282040571&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                    <p>
                        Fos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore
                    </p>
                </div>

                <div>
                    <h3>Ian Barnes</h3>
                    <iframe width="100%" height="166" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/282040571&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                    <p>
                        Fos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore
                    </p>
                </div>

                <div>
                    <h3>Adarsh Mandi</h3>
                    <iframe width="100%" height="166" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/282040571&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                    <p>
                        Fos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore
                    </p>
                </div>


                <hr>

                <div id="madhav" class="row">

                    <div class="col-md-6">
                        <img src="//placehold.it/600x600" class="img-responsive">
                    </div>

                    <div class="col-md-6">
                        <h2 class="text-center">Madhav Sharma</h2>
                        <ul class="madhavBullets">
                            <li>Hosts the podcast</li>
                            <li>Knows Karate, Kung-fu, Taek-won-do and many other words </li>
                            <li>Has never said no to <a class="highlight" target="_blank" href="https://www.google.co.in/search?q=biriyani+facts&espv=2&biw=1366&bih=638&source=lnms&tbm=isch&sa=X&ved=0ahUKEwiAv8jHz_PPAhVBQI8KHZwlCCQQ_AUICCgB#tbm=isch&q=biriyani">Biriyani</a>
                            </li>
                            <li>Commiting grammatical mistakes since 1994</li>
                            <li>Morning routines include skipping the gym and going back to sleep</li>
                        </ul>
                    </div>
                </div>

                <hr>

                <!-- <h2 id="guests">Guests</h2>
                <p>
                    Fos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut..</p>
                <div class="row">
					<div class="col-md-4">
                        <img src="img/guests/Roland Jenson.jpg" class="img-responsive guestImage">
                        <p class="nameTags"> <a href="#rolandJenson">Roland Jenson - The Indian journey</a></p>
                    </div>
					
                    <div class="col-md-4">
                        <img src="img/guests/Roland Jenson.jpg" class="img-responsive guestImage ">
                        <p class="nameTags">Roland Jenson</p>
                    </div>
                    <div class="col-md-4">
                        <img src="img/guests/Roland Jenson.jpg" class="img-responsive guestImage">
                        <p class="nameTags">Roland Jenson</p>
                    </div>
                </div> -->
				
                <h2 id="contact">Contact Us</h2>
                <p>
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae </p>

				
				<!-- <div class="socialMediaIcons" >
					<img src="img/socialMediaIcons/fb.png" alt="Facebook Icon" />
					<img src="img/twitter.png" alt="Twitter Icon" />
				</div> -->
				

                <form class="form-horizontal contact" action="gdform.php" method="post" >
				
<!-- 					<input type="hidden" name="redirect" value="#" />
 -->					<input type="hidden" name="subject" value="Inputs from PeoplePodcast.in"  />
					
					
                    <div class="form-group">
                        <label for="name" class="col-sm-2 control-label">Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control " id="name" placeholder="Basanti">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email" class="col-sm-2 control-label">Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control " id="email" placeholder="basanti@BhaagDhannoBhaag.com">
                        </div>
                    </div>
					
					<div class="form-group">
                        <label for="comments" class="col-sm-2 control-label">Message</label>
                        <div class="col-sm-10">
                            <textarea id = "comments" class="form-control" rows="3" placeholder="Dekho, Yun toh Humein Befuzool Baat Karne Ki Aadat Toh Hai Nahin…" ></textarea>
                        </div>
                    </div>
					
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-default">Send</button>
                        </div>
                    </div>
                </form>
				
                <hr>

            </div>
            <!--/right-->
        </div>
        <!--/row-->
    </div>
    <!--/container-->



    <!-- script references -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
</body>

</html>