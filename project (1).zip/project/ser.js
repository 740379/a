var dotenv = require('dotenv');

dotenv.load();


var knex = require('knex')({
  client: process.env.DB_CLIENT,
  connection: {
    host : process.env.DB_HOST,
	port : process.env.DB_PORT,
	user : process.env.DB_USER,
	password : process.env.DB_PASS,
	database : process.env.DB_DBNAME,
	charset : process.env.DB_CHARSET
  }
});

var PostgreSql = require('bookshelf')(knex);

var Blogs = PostgreSql.Model.extend({
	tableName: 'blogs'
});

var Blogx = PostgreSql.Model.extend({
	tableName: 'blogx'
});

// Creating New Table with Checking whether the table exists or not ...  
PostgreSql.knex.schema.hasTable('blogx').then(function(exists) {
	if (!exists) {
		PostgreSql.knex.schema.createTable('blogx', function(blogss){
			blogss.increments('id').primary();
			blogss.text('name', 100);
		}).then( function (table){
			console.log('Created blogx table');
		});
	}
});

// Fetching Data From Database 
Blogs.fetchAll()
	.then(function (blogs) {
		for(var i = 0; i < blogs.length; i++) {
 		//console.log(blogs.at(i).attributes);
		}
	})

	.catch(function (err) {
		console.log(err);
		// Send Status Number & error Back to Front END (500)
	});

// Inserting data into existing database

var blogx = new Blogx({
	name : 'Hello'
});	
blogx.save()
	.then( function(status) {
		//console.log(status);
	})
	.catch( function(err) {
		console.log(err);
	});


// Updating values in Database

var blogx = new Blogx({
	id  : 1,
	name : 'Hello User'
});	
blogx.save()
	.then( function(status) {
		//console.log(status);
	})
	.catch( function(err) {
		console.log(err);
	});






